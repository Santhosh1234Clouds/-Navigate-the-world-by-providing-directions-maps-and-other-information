const axios = require('axios');

// Get route using Google Maps API for a specific travel mode
const getRoute = async (req, res) => {
    const { startLocation, endLocation, travelMode } = req.query;
    try {
        const response = await axios.get(`https://maps.googleapis.com/maps/api/directions/json`, {
            params: {
                origin: startLocation,
                destination: endLocation,
                mode: travelMode.toLowerCase(),
                key: process.env.MAPS_API_KEY,
            },
        });

        const routes = response.data.routes[0].legs[0];
        res.json(routes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = { getRoute };
