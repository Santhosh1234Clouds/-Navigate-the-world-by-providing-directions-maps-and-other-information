const bcrypt = require('bcryptjs');
const User = require('../models/userModel');

// Register a new user
const registerUser = async (req, res) => {
    const { firstName, lastName, email, phone, username, password } = req.body;

    try {
        // Check if the username or email already exists
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: 'Username or email already exists' });
        }

        // Hash the password before saving
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = new User({ firstName, lastName, email, phone, username, password: hashedPassword });
        await newUser.save();

        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Error registering user:', error.message || error);
        res.status(500).json({ message: 'Error registering user', error: error.message || 'Internal Server Error' });
    }
};

// Login a user
const loginUser = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find user by username
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        // Compare the provided password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        // Login successful
        res.status(200).json({
            message: 'Login successful',
            user: { username: user.username, firstName: user.firstName }
        });
    } catch (error) {
        console.error('Error during login:', error.message || error);
        res.status(500).json({ message: 'Error logging in user', error: error.message || 'Internal Server Error' });
    }
};

module.exports = { registerUser, loginUser };
