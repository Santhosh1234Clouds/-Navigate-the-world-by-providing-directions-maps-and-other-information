const express = require('express');
const { getRoute } = require('../controllers/mapController');
const router = express.Router();

router.get('/route', getRoute);

module.exports = router;
