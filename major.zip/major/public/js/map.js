let map, directionsService, directionsRenderer, userMarker, streetViewPanorama;
let currentStepIndex = 0; // Index for tracking the current step
let liveRouteInterval; // Interval for live route tracking
let leg; // Variable to hold the route leg

document.addEventListener('DOMContentLoaded', () => {
    initializeMap();
    const routeForm = document.getElementById('routeForm');
    routeForm.addEventListener('submit', handleRouteFormSubmit);
    
    const getLocationButton = document.getElementById('getLocation');
    getLocationButton.addEventListener('click', getCurrentLocation);
});

// Initialize the map and autocomplete for locations
function initializeMap() {
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 37.7749, lng: -122.4194 }, // Center on San Francisco
        zoom: 13,
    });

    directionsRenderer.setMap(map);

    // Initialize Street View
    streetViewPanorama = new google.maps.StreetViewPanorama(document.getElementById('streetView'), {
        visible: false, // Initially hidden
    });

    const startInput = document.getElementById('start');
    const destinationInput = document.getElementById('destination');

    const autocompleteStart = new google.maps.places.Autocomplete(startInput);
    const autocompleteDestination = new google.maps.places.Autocomplete(destinationInput);
}

// Handle the form submission to get the route
async function handleRouteFormSubmit(event) {
    event.preventDefault();

    const startLocation = document.getElementById('start').value || userMarker.getPosition();
    const destination = document.getElementById('destination').value;
    const travelMode = document.getElementById('travelMode').value;

    if (!startLocation || !destination) {
        alert('Please provide both start and destination locations.');
        return;
    }

    const routeOptions = {
        origin: startLocation,
        destination: destination,
        travelMode: google.maps.TravelMode[travelMode],
    };

    try {
        const result = await directionsService.route(routeOptions);
        directionsRenderer.setDirections(result);
        displayTravelInfo(result.routes[0].legs[0]); // Display travel time and distance
        leg = result.routes[0].legs[0]; // Store the leg for step tracking

        // Start tracking the user's live route
        currentStepIndex = 0; // Reset step index
        trackLiveRoute(); // Start live route tracking
    } catch (error) {
        console.error('Error fetching directions:', error);
        alert('Could not fetch directions. Please try again.');
    }
}

// Display travel information (duration and distance)
function displayTravelInfo(leg) {
    const travelInfoDiv = document.getElementById('travelInfo');
    const duration = leg.duration.text; // Get the duration text
    const distance = leg.distance.text; // Get the distance text

    travelInfoDiv.innerHTML = `
        <strong>Estimated Travel Time:</strong> ${duration} <br>
        <strong>Distance:</strong> ${distance}
    `;
}

// Track live route process
function trackLiveRoute() {
    const liveRouteDiv = document.getElementById('liveRoute');

    // Clear previous interval if any
    if (liveRouteInterval) {
        clearInterval(liveRouteInterval);
    }

    // Start tracking the user's route with an interval
    liveRouteInterval = setInterval(() => {
        if (currentStepIndex < leg.steps.length) {
            const step = leg.steps[currentStepIndex];

            // Check if the user has reached the current step's end location
            if (userMarker) {
                const userPosition = userMarker.getPosition();
                const stepEndLocation = step.end_location;
                const distanceToEnd = google.maps.geometry.spherical.computeDistanceBetween(userPosition, stepEndLocation);
                
                // If user is close to the end of the step, increment the step index
                if (distanceToEnd < 30) { // Close enough to the step end (30 meters)
                    currentStepIndex++; // Move to the next step
                    if (currentStepIndex < leg.steps.length) {
                        const nextStep = leg.steps[currentStepIndex];
                        const stepInstruction = nextStep.instructions.replace(/<[^>]*>/g, ''); // Remove HTML tags
                        liveRouteDiv.innerHTML = `Next Step: ${currentStepIndex + 1}. ${stepInstruction} (${nextStep.distance.text}, ${nextStep.duration.text})`;

                        // Update Street View position
                        updateStreetView(nextStep.end_location);
                    } else {
                        liveRouteDiv.innerHTML = 'You have reached your destination!';
                        clearInterval(liveRouteInterval); // Clear the interval when the destination is reached
                    }
                } else {
                    // Provide live instructions for the current step
                    const stepInstruction = step.instructions.replace(/<[^>]*>/g, ''); // Remove HTML tags
                    liveRouteDiv.innerHTML = `Current Step: ${currentStepIndex + 1}. ${stepInstruction} (${step.distance.text}, ${step.duration.text})`;
                }
            }
        }
    }, 5000); // Update every 5 seconds
}

// Update Street View based on location
function updateStreetView(location) {
    streetViewPanorama.setPosition(location);
    streetViewPanorama.setVisible(true); // Make Street View visible
}

// Get Current Location
function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
            };

            if (userMarker) {
                userMarker.setMap(null); // Remove previous marker
            }

            userMarker = new google.maps.Marker({
                position: userLocation,
                map: map,
                title: 'Your Current Location',
            });

            map.setCenter(userLocation);
            document.getElementById('start').value = `${userLocation.lat}, ${userLocation.lng}`; // Set the start location input

            // Update Street View to current location
            updateStreetView(userLocation);
        }, () => {
            handleLocationError(true);
        });
    } else {
        // Browser doesn't support Geolocation
        handleLocationError(false);
    }
}

// Handle location error
function handleLocationError(browserHasGeolocation) {
    alert(browserHasGeolocation ?
          'Error: The Geolocation service failed.' :
          'Error: Your browser doesn\'t support geolocation.');
}
// Handle registration form submission
document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    try {
        const response = await fetch('/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ firstName, lastName, email, phone, password, confirmPassword }),
        });

        const result = await response.json();
        if (response.status === 201) {
            alert('Registration successful. Please login.');
            window.location.href = '/login.html'; // Redirect to login page
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
});

// Handle login form submission
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/public/js/map.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });

        const result = await response.json();
        if (response.status === 200) {
            alert('Login successful');
            localStorage.setItem('token', result.token); // Store the JWT token
            window.location.href = '/public/index.html'; // Redirect to main page
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Error:', error);
    }
});

